# Scripts
This directory contains scripts that were used in creating the benchmark.
They are 

`create_study.py`: used to generate the OpenML benchmark suite: openml.org/s/218
`find_matching_datasets.py`: used to determine the datasets which are in this benchmark but also used for warm-starting `auto-sklearn`.