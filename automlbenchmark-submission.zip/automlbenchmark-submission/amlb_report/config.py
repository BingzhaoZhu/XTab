
nfolds = 10
ff = '%.6g'
colormap = 'colorblind'
# colormap = 'tab10'
# colormap = 'Set2'
# colormap = 'Dark2'
