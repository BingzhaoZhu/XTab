---
title: BibTeX - AutoML @ ICML 2019 Paper
---
```
@article{amlb2019,
  title={An Open Source AutoML Benchmark},
  author={Gijsbers, P. and LeDell, E. and Poirier, S. and Thomas, J. and Bischl, B. and Vanschoren, J.},
  journal={arXiv preprint arXiv:1907.00909 [cs.LG]},
  url={https://arxiv.org/abs/1907.00909},
  note={Accepted at AutoML Workshop at ICML 2019},
  year={2019}
}

```