---
layout: category
title: Documentation
sidebar_sort_order: 4
---

 - [Running the Benchmark](README.md#running-benchmarks)
 - [Adding a dataset](extending.md#adding-a-dataset)
 - [Adding an AutoML Framework](extending.md#adding-an-automl-framework)