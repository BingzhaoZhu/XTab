# Reports for 2019 AutoML Benchmark

These notebooks are built based on a previous iteration of the AutoML benchmark output, so will not work out-of-the-box with the new result files.
