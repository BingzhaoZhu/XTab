
class AutoMLError(Exception):
    pass


class InvalidStateError(AutoMLError):
    pass
