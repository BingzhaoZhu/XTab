# Welcome to Contributing to AutoGLuon-Cloud!
We do not run CI on your PRs directly for security reasons.
Please @ the maintainers to add `cloud safe to test` label to the PR so that they can kick off the CI for you.
The above statement is true for each commit you push as we cannot make assumption that your commit is always benign.
