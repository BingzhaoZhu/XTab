from .predictor import (
    TabularCloudPredictor,
    TextCloudPredictor,
    ImageCloudPredictor,
    MultiModalCloudPredictor,
)
