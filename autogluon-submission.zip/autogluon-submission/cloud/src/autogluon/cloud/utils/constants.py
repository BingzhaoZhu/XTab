VALID_ACCEPT = [
    'application/x-parquet',
    'text/csv',
    'application/json'
]

SAGEMAKER_RESOURCE_PREFIX = 'ag-cloudpredictor'

LOCAL_MODE = 'local'
MODEL_ARTIFACT_NAME = 'model.tar.gz'
