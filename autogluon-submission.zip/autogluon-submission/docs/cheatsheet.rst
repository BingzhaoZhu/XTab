Cheat Sheet
-----------

.. image:: https://raw.githubusercontent.com/Innixma/autogluon-doc-utils/main/docs/cheatsheets/stable/autogluon-cheat-sheet.jpeg
   :width: 900

Download the PDF version with clickable links `here`_.

.. _Here: https://nbviewer.org/github/Innixma/autogluon-doc-utils/blob/main/docs/cheatsheets/stable/autogluon-cheat-sheet.pdf

Looking for a different version? Refer to the `autogluon-doc-utils`_ repo to view all versions of the cheatsheet.

.. _autogluon-doc-utils: https://github.com/Innixma/autogluon-doc-utils/tree/main/docs/cheatsheets
