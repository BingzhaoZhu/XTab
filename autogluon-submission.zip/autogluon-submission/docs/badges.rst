.. |ReleaseVersion| image:: https://img.shields.io/badge/doc%20release-v0.5.2-blue
.. _ReleaseVersion: https://auto.gluon.ai/dev/versions.html
.. |StableVersion| image:: https://img.shields.io/github/v/release/awslabs/autogluon?color=blue&label=stable%20release&sort=semver
.. _StableVersion: https://auto.gluon.ai/stable/index.html
.. |PythonVersion| image:: https://img.shields.io/badge/python-3.7%20%7C%203.8%20%7C%203.9-blue
.. _PythonVersion: https://pypi.org/project/autogluon/
.. |GitHub| image:: https://img.shields.io/github/stars/awslabs/autogluon?style=social
.. _GitHub: https://github.com/awslabs/autogluon/stargazers
.. |Twitter| image:: https://img.shields.io/twitter/follow/autogluon?style=social
.. _Twitter: https://twitter.com/autogluon
.. |Downloads| image:: https://pepy.tech/badge/autogluon/month
.. _Downloads: https://pepy.tech/project/autogluon
.. |License| image:: https://img.shields.io/github/license/awslabs/autogluon?color=blue
.. _License: https://github.com/awslabs/autogluon/blob/master/LICENSE

|ReleaseVersion|_ |StableVersion|_ |PythonVersion|_ |License|_ |Downloads|_ |GitHub|_ |Twitter|_
