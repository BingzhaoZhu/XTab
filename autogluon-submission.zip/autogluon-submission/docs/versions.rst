Available Documentation for AutoGluon
-------------------------------------

Web-based documentation is available for versions listed below:

- `AutoGluon 0.5.3 (dev) documentation <https://auto.gluon.ai/dev/index.html>`_
- `AutoGluon 0.5.2 (stable) documentation <https://auto.gluon.ai/stable/index.html>`_
- `AutoGluon 0.5.1 documentation <https://auto.gluon.ai/0.5.1/index.html>`_
- `AutoGluon 0.5.0 documentation <https://auto.gluon.ai/0.5.0/index.html>`_
- `AutoGluon 0.4.2 documentation <https://auto.gluon.ai/0.4.2/index.html>`_
- `AutoGluon 0.4.1 documentation <https://auto.gluon.ai/0.4.1/index.html>`_
- `AutoGluon 0.4.0 documentation <https://auto.gluon.ai/0.4.0/index.html>`_
- `AutoGluon 0.3.1 documentation <https://auto.gluon.ai/0.3.1/index.html>`_
- `AutoGluon 0.3.0 documentation <https://auto.gluon.ai/0.3.0/index.html>`_
- `AutoGluon 0.2.0 documentation <https://auto.gluon.ai/0.2.0/index.html>`_
- `AutoGluon 0.1.0 documentation <https://auto.gluon.ai/0.1.0/index.html>`_
- `AutoGluon 0.0.15 (legacy) documentation <https://auto.gluon.ai/0.0.15/index.html>`_
