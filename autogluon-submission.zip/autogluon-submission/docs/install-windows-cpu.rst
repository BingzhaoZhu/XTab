.. note::

    .. include:: install-windows-generic.rst

    .. code-block:: bash

        conda create -n myenv python=3.9 -y
        conda activate myenv

    4. Continue with the remaining installation steps using the conda environment created above
