.. warning::
    This documentation is based off of the pre-release mainline branch which may have frequent API breaking changes.

    Most users should instead reference the `stable release documentation <https://auto.gluon.ai/stable/index.html>`_.
