

class ExhaustedSearchSpaceError(Exception):
    pass
